export const defaultDateRange = [
  {
    label: 'Last 7 days',
    value: 'Last 7 days',
  },
  {
    label: 'Month to date',
    value: 'Month to date',
  },
  {
    label: 'Last 4 weeks',
    value: 'Last 4 weeks',
  },
  {
    label: 'Last 3 months',
    value: 'Last 3 months',
  },
  {
    label: 'Last 6 months',
    value: 'Last 6 months',
  },
  {
    label: 'Last 12 months',
    value: 'Last 12 months',
  },
];
