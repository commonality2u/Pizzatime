import React from 'react';

const Page = () => {
  return <div>Analytics</div>;
};
export default Page;
