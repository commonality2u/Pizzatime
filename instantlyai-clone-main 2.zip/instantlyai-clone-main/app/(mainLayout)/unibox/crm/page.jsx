import React from 'react';

const Page = () => {
  return <div>Feature not available yet.</div>;
};

export default Page;
