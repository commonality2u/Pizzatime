import React from 'react';

const Page = () => {
  return <div>Options</div>;
};

export default Page;
