import React from 'react';

export function Collapse() {
  return <div>Collapse</div>;
}
